# Student Enrollment Form

## Project Description
Web-based form using HTML, Bootstrap, JavaScript, and JsonPowerDB.

## Features
- Add student
- Update student
- Reset form
- Validation

## Database
- SCHOOL-DB
- STUDENT-TABLE
- Primary Key: Roll-No
